package com.atmproject;

public interface ATMinterf {
	public void CheckBalance();
	public void Withdraw(double Withdraw);
	public void Deposit(double Deposit);
	public void viewStatement();

}
