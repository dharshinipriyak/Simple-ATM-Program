package com.atmproject;

import java.util.HashMap;
import java.util.Map;

public class ATMimpl implements ATMinterf
{
//create object of the ATM class
	ATM atm=new ATM();//create object
	Map<Double,String> viewstat=new HashMap<>();//amount and the type of transaction
	@Override
	public void CheckBalance() 
	{
		System.out.println("Your Available balance is : "+atm.getCheckBalance());	
	}

	@Override
	public void Withdraw(double Withdraw)
	{
		if(Withdraw%100==0) 
		{
			if(Withdraw<=atm.getCheckBalance()) 
			{
				System.out.println("Kindly Please Collect Your cash "+Withdraw);
				atm.setCheckBalance(atm.getCheckBalance()-Withdraw);
				CheckBalance();//After withdraw,going to display available balance
		
				//after withdrawal, the statement has to be display
				viewstat.put(Withdraw, " is withdrawn");
			}
			else
			{
				System.out.println("Insufficient Balance");
			}
		}
		System.out.println("Please Enter Amount in Multiple of 100");	
	}

	@Override
	public void Deposit(double Deposit) 
	{
		if(Deposit%200==0)
		{
			System.out.println(Deposit+" deposited Successfully !!");
			atm.setCheckBalance(atm.getCheckBalance()+Deposit);
			CheckBalance();
			
			//after deposit,statement is to be display
			viewstat.put(Deposit, " is Deposited");
		}
		else
		{
			System.out.println("Please Deposit the Amount im Multiple of 200");
		}
	}

	@Override
	public void viewStatement()
	{
		for(Map.Entry<Double, String> st:viewstat.entrySet())//shows withdraw and deposit transaction
		{
			System.out.println(st.getKey()+ " "+st.getValue());
		}
		
	}

}
