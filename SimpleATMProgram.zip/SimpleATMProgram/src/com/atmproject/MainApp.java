package com.atmproject;

import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {
		//create object
		ATMinterf op=new ATMimpl();
		int atmpin=6769;
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome to ATM");
		System.out.println("\tPlease Enter your\nPersonal Identification Number");
		int pin=sc.nextInt();
				if(atmpin==pin)
				{
				while(true)
				{
				System.out.println("Please Select Your Desired Option");
				System.out.println("1.Check Balance\n2.Withdraw\n3.CashDeposit\n4.ViewStatement\n5.Exit");
				int ch=sc.nextInt();
				 if(ch==1) 
				 {//Check balance
					op.CheckBalance();
				 }
				 else if(ch==2)
				 {//Withdraw
					 System.out.println("Please Enter the Amount to Withdraw");
					 double Withdraw=sc.nextDouble();
					 op.Withdraw(Withdraw);
					
				 }
				 else if(ch==3) 
				 {//Deposit
					 System.out.println("Enter Amount to Deposit : ");
					 double Deposit=sc.nextDouble();
					 op.Deposit(Deposit);
					 
				 }
				 else if(ch==4)
				 {	 //Statement
					 op.viewStatement();
				 }
				 else
				 {//Exit
					 System.out.println("Your transaction Cancelled");
					 System.out.println("Thank you for visiting ATM\n***Please Visit Again**");
					 System.exit(0);

				 }
				
			}
		}
		else
		{
		System.out.println("XXXIncorrect PIN numberXXXX");
					
		}
sc.close();
	}

}
