package com.atmproject;

public class ATM {
	private double CheckBalance;
	private double Deposit;
	private double Withdraw;
public ATM() 
	{
	}
public double getCheckBalance()
	{
		return CheckBalance;
	}
	public void setCheckBalance(double checkBalance)
		{
		CheckBalance = checkBalance;
		}
public double getDeposit()
	{
	return Deposit;
	}
		public void setDeposit(double deposit) 
		{
			Deposit = deposit;
		}
public double getWithdraw() 
		{
	return Withdraw;
		}
		public void setWithdraw(double withdraw) 
		{
			Withdraw = withdraw;
		}
}
